phan mem mo phong osc la Soundcard scope
chu y cac file hinh thoi:
-chup man hinh
-Luu tu soundcard scope gom 2 hinh trang va den
-hinh ve lai tu matlab
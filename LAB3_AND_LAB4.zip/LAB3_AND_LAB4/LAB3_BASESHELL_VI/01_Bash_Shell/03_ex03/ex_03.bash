rm -rf ./folder_02/*   # Delete all file in folder_02
cp -rf ./folder_01/{file_V01.v,file_V02.v,file_V03.v,file_V04.v} ./folder_02/  # Copy all file *.v from folder_01 to folder_02
rm -rf ./folder_01/{file_V01.v,file_V02.v,file_V03.v,file_V04.v}  # Remove all file *.v from folder_01

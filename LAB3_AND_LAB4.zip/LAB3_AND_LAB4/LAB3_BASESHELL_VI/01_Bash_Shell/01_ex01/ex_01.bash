rm -rf folder_02/*
cp -rf folder_01/file_01.v folder_02/file_02.v


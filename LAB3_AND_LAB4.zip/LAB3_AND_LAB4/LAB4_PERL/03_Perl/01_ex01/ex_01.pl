#!/usr/bin/perl -w

unlink glob ("./folder_02/*");   # Delete all files in folder_02


use File::Copy qw(copy);   # Copy file_01 to folder_02
my $old_folder = "./folder_01/file_01.v";
my $new_folder = "./folder_02/file_01.v";
copy $old_folder, $new_folder;


use strict;
use warnings;
my $line = 0;
my $file_name = "./folder_02/file_01.v";
my $file_out = "./folder_02/file_tmp.v";
open(my $OUT, '>', $file_out) || die "file could not open $! \n";
open(my $FILE, '<', $file_name) || die "file could not open $! \n";
while( $line = <$FILE>) {
        if( $line =~ s/\bPARAMETER_WIDTH\b/3/ig ) {  # Change PARAMETER_WIDTH by 3 
                print  $OUT $line;
        } else {
                print  $OUT $line;
        }
}
close($FILE);
close($OUT);
copy $file_out, $file_name;
unlink glob ("./folder_02/file_tmp.v");   #Remove temporary file

#!/usr/bin/perl -w

unlink glob ("./folder_02/*");   # Delete all files in folder_02

use File::Copy qw(copy);
my $old_folder = "./folder_01/file_01.v";
my $new_folder = "./folder_02/file_02.v";
copy $old_folder, $new_folder;  # Copy file_01 from folder_01 to folder_02 and change name to file_02


use strict;
use warnings;
my $line = 0;
my $file_name = "./folder_02/file_02.v";
my $file_out = "./folder_02/file_tmp.v";
open(my $OUT, '>', $file_out) || die "file could not open $! \n";
open(my $FILE, '<', $file_name) || die "file could not open $! \n";
my $PARAMETER_INPUT  = $ARGV[0];           # Difine argument
my $PARAMETER_ADDR_WIDTH  = $ARGV[1];          # Difine argument
my $PARAMETER_BUS_WIDTH  = $ARGV[2];          # Difine argument
my $PARAMETER_NET_WIDTH  = $ARGV[3];          # Difine argument
while( $line = <$FILE>) {
        if( $line =~ s/\bPARAMETER_WIDTH\b/$PARAMETER_INPUT/ig ) {   # Replace PARAMETER_WIDTH by the first input arguement
                print  $OUT $line;
        } elsif ( $line =~ /INSERT PARAMETER/) {      # Add 3 line below line  //INSERT PARAMETER
                print  $OUT $line;
                print  $OUT "parameter ADDR_WIDTH = $PARAMETER_ADDR_WIDTH;\n";
                print  $OUT "parameter BUS_WIDTH = $PARAMETER_BUS_WIDTH;\n";
                print  $OUT "parameter NET_WIDTH = $PARAMETER_NET_WIDTH;\n";
        } else {
                print  $OUT $line;
        }
}
close($FILE);
close($OUT);
copy $file_out, $file_name;    
unlink glob ("./folder_02/file_tmp.v");   # Remove temporary file

rm -rf ./folder_02/*   # Delete all file in folder_02

for i in $(find  -path "./folder_01/file*V0*v")     # Find all find with format file*V0*v in folder_01
do
if [ $i = './folder_01/file_V01_T01.v' ]  # Replace name for file file_V01_T01.v
then
cp -rf $i ./folder_02/XXX_V44.v       # Copy file from folder_01 to folder_02
fi

if [ $i = './folder_01/file_V02_T02.v' ]  # Replace name for file file_V02_T02.v
then
cp -rf $i ./folder_02/XXX_V33.v       # Copy file from folder_01 to folder_02
fi

if [ $i = './folder_01/file_V03_T03.v' ]  # Replace name for file file_V03_T03.v
then
cp -rf $i ./folder_02/XXX_V22.v       # Copy file from folder_01 to folder_02
fi

if [ $i = './folder_01/file_V04_T04.v' ]  # Replace name for file file_V04_T04.v
then
cp -rf $i ./folder_02/XXX_V11.v       # Copy file from folder_01 to folder_02
fi
done

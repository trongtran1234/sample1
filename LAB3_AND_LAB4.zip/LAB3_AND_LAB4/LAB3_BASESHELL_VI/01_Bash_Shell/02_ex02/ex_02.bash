#!/bin/bash

rm -rf folder_02/*  # Remove all files in folder_02


argument=$1    # variable argument will be assigned to the first argument
file_name=file_$argument
tail_name=".v"
file_name_full=${file_name}${tail_name}


cp -rf ./folder_01/$file_name_full ./folder_02/   # Copy specific file to folder_02
